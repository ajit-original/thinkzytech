const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  const token = req.header('auth-token');
  if (!token) {
    return res.status(401).json({ msg: `Token is not found.` });
  } else {
    try {
      req.user = jwt.verify(token, 'jwtSecret').user;
      next();
    } catch (err) {
      console.log(err.message);
      res.status(401).json({ msg: `Token is not valid.` });
    }
  }
};
