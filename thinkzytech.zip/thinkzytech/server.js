const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const auth = require('./middleware/auth');
const Product = require('./models/Product');
const User = require('./models/User');

const app = express();

app.use(express.json());

mongoose.connect(
  'mongodb+srv://ajit123:ajit123@developersmedia.kizjl.mongodb.net/thinkzytech?retryWrites=true&w=majority',
  () => {
    console.log(`MongoDB connected...`);
  }
);

// get user by token
app.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    res.json(user);
  } catch (err) {
    console.log(err.message);
    res.status(500).send(`Server error`);
  }
});

// registration
app.post('/register', async (req, res) => {
  let userEmail = req.body.email;

  let user = await User.findOne({ email: userEmail });
  try {
    if (user) {
      return res.status(400).json({ msg: `Email already exists!` });
    } else {
      user = new User({
        isAdmin: req.body.isAdmin,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: userEmail,
        contact: req.body.contact,
        password: req.body.password,
      });

      await user.save();

      const payload = {
        user: {
          id: user.id,
        },
      };

      jwt.sign(payload, 'jwtSecret', { expiresIn: 360000 }, (err, token) => {
        if (err) throw err;
        res.json({ token });
      });
    }
  } catch (err) {
    console.log(err.message);
    res.status(500).send(`Server error`);
  }
});

// login
app.post('/login', async (req, res) => {
  let userEmail = req.body.email;
  let user = await User.findOne({ email: userEmail });
  try {
    if (!user) {
      return res.status(400).json({ msg: `Email is not registerd.` });
    } else {
      if (req.body.password !== user.password) {
        return res.status(400).json({ msg: `Password do not match.` });
      }

      const payload = {
        user: {
          id: user.id,
        },
      };

      jwt.sign(payload, 'jwtSecret', { expiresIn: 360000 }, (err, token) => {
        if (err) throw err;
        res.json({ token });
      });
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).send(`Server error`);
  }
});

// upload product
app.post('/upload-product', auth, async (req, res) => {
  let product = new Product({
    name: req.body.name,
    model: req.body.model,
    price: req.body.price,
    quantity: req.body.quantity,
  });

  try {
    await product.save();
    res.json(`Product added successfully!`);
  } catch (error) {
    console.log(error);
    res.json({ error });
  }
});

// get all products
app.get('/products', async (req, res) => {
  let products = await Product.find();
  res.json(products);
});

//update product
app.put('/update-product', auth, async (req, res) => {
  let { newName, newModel, newPrice, newQuantity } = req.body;
  var product = await Product.findOne({ model: req.body.model });
  try {
    if (product) {
      let productFields = {};
      if (newName) productFields.name = newName;
      if (newModel) productFields.model = newModel;
      if (newPrice) productFields.price = newPrice;
      if (newQuantity) productFields.quantity = newQuantity;
      product = await Product.findOneAndUpdate(
        { model: req.body.model },
        { $set: productFields },
        { new: true }
      );
      return res.json(product);
    } else {
      return res.status(401).json({ msg: `Product not found.` });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send(`Server error`);
  }
});

// delete product
app.delete('/delete-product', auth, async (req, res) => {
  try {
    await Product.findOneAndRemove({ model: req.body.model });
    res.json({ msg: `Product removed.` });
  } catch (err) {
    console.log(err.message);
    res.status(500).send(`Server error`);
  }
});

// add product to user cart
app.post('/add-to-cart', auth, async (req, res) => {
  var user = await User.findOne({ _id: req.user.id });
  try {
    let item = await Product.findOne({ model: req.body.model });

    user.cart = [
      ...user.cart,
      { name: item.name, model: item.model, price: item.price },
    ];

    await user.save();

    return res.status(200).json(user);
  } catch (err) {
    console.log(err.message);
    res.status(500).send(`Server error`);
  }
});

app.listen(5000, () => {
  console.log(`Server is running at Port: 5000`);
});
