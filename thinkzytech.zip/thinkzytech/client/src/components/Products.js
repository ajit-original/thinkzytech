import axios from 'axios';
import React, { useEffect } from 'react';
import { getProducts } from '../actions/api';

import { useState } from 'react';

function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    updateProducts();
  }, []);

  const updateProducts = async () => {
    var res = await getProducts();
    setProducts(res);
  };

  return (
    <>
      <h1 style={{ textAlign: 'center' }}>Products</h1>
      <div id='productPage'>
        <div>
          {products.map((el, ind) => (
            <p className='productCard' key={ind}>
              Name: {el.name}
              <br />
              <br /> Model: {el.model}
              <br />
              <br /> Price: {el.price}
            </p>
          ))}
        </div>
      </div>
    </>
  );
}

export default Products;
