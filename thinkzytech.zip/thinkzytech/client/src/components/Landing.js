import React from 'react';

function Landing() {
  return (
    <div id='landing'>
      <div id='landing-inner'>
        <h1>Welcome to the Thinkzytech Market</h1>
        <h3>You can visit so many products here</h3>
        <br />
        <h3>Click to Products Tab to see all the products</h3>
      </div>
    </div>
  );
}

export default Landing;
