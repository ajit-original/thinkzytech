import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { signUp } from '../actions/api';

function Signup() {
  const [formData, setFormData] = useState({
    isAdmin: false,
    firstName: '',
    lastName: '',
    email: '',
    contact: null,
    password: '',
    password2: '',
    adminKey: '',
  });

  const [alert, setAlert] = useState('');

  let navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.password2) {
      setAlert(`password mismatch`);
      setTimeout(() => {
        setAlert(``);
        return;
      }, 1000);
    }

    if (formData.adminKey) {
      if (formData.adminKey !== 'adminkey') {
        setAlert(`Invalid Admin Authorization Key`);
        setTimeout(() => {
          setAlert(``);
          return;
        }, 1000);
      } else {
        setFormData({
          ...formData,
          isAdmin: true,
        });
      }
    }

    const data = {
      isAdmin: formData.isAdmin,
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      contact: formData.contact,
      password: formData.password,
    };
    var res = await signUp(data);
    if (res) {
      navigate('../dashboard', { replace: true });
    }
  };

  return (
    <div>
      <h2>Sign Up</h2>

      <form onSubmit={handleSubmit}>
        <h3>{alert}</h3>
        <div className='container'>
          <input
            type='text'
            placeholder='First Name'
            name='firstName'
            value={formData.firstName}
            onChange={(e) => handleChange(e)}
            required
          />
          <input
            type='text'
            placeholder='Last Name'
            name='lastName'
            value={formData.lastName}
            onChange={(e) => handleChange(e)}
            required
          />
          <input
            type='email'
            placeholder='Email ID'
            name='email'
            value={formData.email}
            onChange={(e) => handleChange(e)}
            required
          />
          <input
            type='number'
            placeholder='Contact No.'
            name='contact'
            value={formData.contact}
            onChange={(e) => handleChange(e)}
            required
          />
          <input
            type='password'
            placeholder='Enter Password'
            name='password'
            value={formData.password}
            onChange={(e) => handleChange(e)}
            required
          />
          <input
            type='password'
            placeholder='Re-enter Password'
            name='password2'
            value={formData.password2}
            onChange={(e) => handleChange(e)}
            required
          />
          <input
            type='password'
            placeholder='Are you an Admin? If yes, enter the authorised Key, else skip!'
            name='adminKey'
            value={formData.adminKey}
            onChange={(e) => handleChange(e)}
          />

          <button type='submit'>Register</button>
        </div>
      </form>
    </div>
  );
}

export default Signup;
