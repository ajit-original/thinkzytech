import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

function Navbar(props) {
  const [token, setToken] = useState(null);
  const [admin, setAdmin] = useState(false);
  useEffect(() => {
    if (localStorage.getItem('token')) {
      setToken(localStorage.getItem('token'));
      setAdmin(localStorage.getItem('isAdmin'));
    }
  }, [token, admin]);
  return (
    <div id='navbar'>
      <ul>
        <li>
          <Link to='/'>
            <p>Home</p>
          </Link>
        </li>
        {token && (
          <li>
            <Link to='/products'>
              <p>Products</p>
            </Link>
          </li>
        )}
        {token && admin && (
          <li>
            <Link to='/dashboard'>
              <p>Dashboard</p>
            </Link>
          </li>
        )}
        {token && !admin && (
          <li>
            <Link to='/dashboard'>
              <p>Cart</p>
            </Link>
          </li>
        )}

        {!token && (
          <li style={{ float: 'right' }}>
            <Link to='/register'>
              <p>Register</p>
            </Link>
          </li>
        )}
        {!token && (
          <li style={{ float: 'right' }}>
            <Link className='active' to='/login'>
              <p>Login</p>
            </Link>
          </li>
        )}
        {token && (
          <li style={{ float: 'right' }}>
            <Link className='active' to='/'>
              <p
                onClick={() => {
                  localStorage.clear();
                  window.location.reload();
                }}
              >
                Logout
              </p>
            </Link>
          </li>
        )}
      </ul>
    </div>
  );
}

export default Navbar;
