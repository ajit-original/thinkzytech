import axios from 'axios';
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { getUser } from '../actions/api';

function Dashboard(props) {
  const [token, setToken] = useState(null);
  const [admin, setAdmin] = useState(false);
  useEffect(() => {
    if (localStorage.getItem('token')) {
      setToken(localStorage.getItem('token'));
      setAdmin(localStorage.getItem('isAdmin'));
    }
  });
  return (
    <div>
      {token && admin ? <h1>Dashboard</h1> : <h1>Cart</h1>}
      <br />
      {token && admin ? (
        <p>Hello {localStorage.getItem('userData').firstName}</p>
      ) : null}
    </div>
  );
}

export default Dashboard;
