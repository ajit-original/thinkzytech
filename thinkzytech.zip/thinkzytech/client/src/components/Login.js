import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { login } from '../actions/api';

function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const [alert, setAlert] = useState('');

  let navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== '123456') {
      setAlert(`Invalid password`);
      setTimeout(() => {
        setAlert(``);
      }, 1000);
      return;
    }

    const data = {
      email: formData.email,
      password: formData.password,
    };
    var res = await login(data);
    if (res) {
      navigate('../dashboard', { replace: true });
    }
  };

  return (
    <div>
      <h2>Log In</h2>

      <form onSubmit={handleSubmit}>
        <h3>{alert}</h3>
        <div className='container'>
          <input
            type='email'
            placeholder='Email ID'
            name='email'
            value={formData.email}
            onChange={(e) => handleChange(e)}
            required
          />

          <input
            type='password'
            placeholder='Enter Password'
            name='password'
            value={formData.password}
            onChange={(e) => handleChange(e)}
            required
          />

          <button type='submit'>Log In</button>
        </div>
      </form>
    </div>
  );
}

export default Login;
