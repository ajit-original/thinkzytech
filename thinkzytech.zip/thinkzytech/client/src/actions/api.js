import axios from 'axios';

export const signUp = async (data) => {
  try {
    var res = await axios.post('/register', data);
    console.log(res.data);

    localStorage.setItem('token', res.data.token);

    getUser();
    return res.data;
  } catch (err) {
    console.log(err.message);
  }
};

export const login = async (data) => {
  try {
    var res = await axios.post('/login', data);

    console.log(res.data);

    localStorage.setItem('token', res.data.token);

    getUser();
    return res.data;
  } catch (err) {
    console.log(err.message);
  }
};

export const getProducts = async () => {
  try {
    var res = await axios.get('/products');
    return res.data;
  } catch (err) {
    console.log(err.message);
  }
};

export const getUser = async () => {
  let token = localStorage.getItem('token');
  let header = { 'auth-token': token };
  try {
    var res = await axios.get('/me', { headers: header });
    console.log(res);
    localStorage.setItem('userData', res.data);
    try {
      localStorage.setItem('isAdmin', res.data.isAdmin);
    } catch (error) {
      localStorage.setItem('isAdmin', false);
      console.log(error);
    }

    console.log('under getUser api: ', res.data);
    return res.data;
  } catch (err) {
    console.log(err.message);
  }
};
